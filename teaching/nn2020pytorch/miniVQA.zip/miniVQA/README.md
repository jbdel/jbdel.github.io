# miniVQA
train.csv et val.csv sont les splits d'entrainement

test.csv est le split du challenge, sans le label

answer_key.csv sont les labels de test.csv, qu'il faut uploader sur kaggle (ficher solution)

sample_submission.csv est une solution random (~1% accuracy)

image_question.json cartographie les images et les questions

answer_list.txt cartographie les labels avec les réponses en langage naturel

les images sont dispo ici : https://docs.google.com/uc?export=download&id=1pfd5-i_F20zViKIYwbQ8jL1p78s_E6uX

Le dataset peut etre créé from scratch (avec les images) ici avec le process_miniVQA.ipynb (sous dataset de mscoco)